
import os
import zipfile
import struct
import shutil
import sys
import configparser

zip = os.path.dirname(__file__)
cfg = configparser.ConfigParser()
with zipfile.ZipFile(zip, "r") as archive:
    with archive.open(environment.ini, 'r') as handle:
        cfg.read(handle)
    print (cfg)
    deploy_path = cfg[deploy][folder]
    checksum = cfg[deploy][checksum]
        
if not os.path.isdir(deploy_path):
    print ("fresh deployment, unpacking into " + deploy_path)
    shutil.unpack_archive(zip, deploy_path)
    sys.exit(0)
else:
    parser = configparser.ConfigParser
    checksum_file = os.path.join(deploy_path, environment.ini)
    parser.read(checksum_file)
    saved_checksum = parser[deploy][checksum]
    print("zip checksum", checksum, "disk checksum", saved_checksum)
    if (checksum == saved_checksum):
        print ("dependencies unchanged")
        sys.exit(0)
    else:
        print ("dependencies have changed, updating deployment")
        shutil.rmtree(deploy_path)
        shutil.unpack_archive(zip, extract_dir = deploy_path)
